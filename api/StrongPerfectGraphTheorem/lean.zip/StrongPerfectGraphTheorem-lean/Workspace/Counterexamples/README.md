# Counterexamples

Countermodels, not steps of the proof.  Nothing in `Workspace` imports this folder, so the
main theorem `Workspace.MainTheorem.SPGT.thm_1_2` does not depend on any of it.

Each module here exists to justify a place where the repository departs from the paper: it
builds one explicit finite graph, checks every hypothesis of the printed statement, and shows
the printed conclusion fails.  Each is checked by `decide` and carries no `sorry`.

* `Thm93.lean` — **statement 9.3, outcome 4, is false as printed.**  An eleven-vertex graph
  satisfying every hypothesis of `Workspace.Statements.S09.SPGT.thm_9_3` and refuting the
  printed conclusion (`printed_nine_three_false`), while satisfying the repaired conclusion
  that the repository proves (`repaired_conclusion11`).  The two together fix the repair: the
  printed clause fails here, the weakened clause holds.  The matching erratum is the 9.3 entry
  of `formaliaxiv.json` and row A1 of `FAITHFULNESS_AUDIT.md`.
